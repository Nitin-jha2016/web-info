import React,{useState,useEffect} from "react";
import { MyContext } from "../App";
import { Modal, Button } from "react-bootstrap";
import EmpRecordTable from "./EmpRecordTable";
import DataTable,{createTheme} from "react-data-table-component";

function EmpRecordModal() {
  const { show, setShow, id, token, getempDataRecord,modalType,setmodalType,empData,empDataRecord,insertempDataRecord } = React.useContext(MyContext);
  const [fromDate, setfromDate] = useState('')
  const [toDate, settoDate] = useState('')
  console.log('MODAL TYPE',modalType);

  const [date, setdate] = useState('')
  const [empName, setempName] = useState('')
  const [project, setproject] = useState('')
  const [backupPath, setbackupPath] = useState('')

console.log('empdatarcord&&&&',empDataRecord);

useEffect(() => {
   if(empData.length > 0){console.log('EMP DATA',empData);
   let filterdata = empData.filter(data => data.id == id);
   console.log(filterdata);
   setempName(filterdata[0].Emp_name);
   setproject(filterdata[0].project);
   setbackupPath(filterdata[0].backup_desti);}

}, [id])

let columns = [
  {
     name: 'backup_path',
     selector: 'backup_path',
     wrap: true
  },
  {
    name: 'date',
    selector: 'date',
    wrap: true
 },
 {
  name: 'emp_name',
  selector: 'emp_name',
  wrap: true
},
{
  name: 'project',
  selector: 'project',
  wrap: true
}
]

  return (
    <>
      <Modal
        show={show}
        onHide={() => setShow(false)}
        dialogClassName="modal-100w"
        aria-labelledby="example-custom-modal-styling-title"
      >
        <Modal.Header closeButton>
          <Modal.Title id="example-custom-modal-styling-title">
            EMPLOYEE RECORD
          </Modal.Title>
        </Modal.Header>
        <Modal.Body>
         {modalType == 'showinfo' && <><div className="modal-inputs">
            <div className="mr-2" style={{ marginLeft: "10px" }}>
              <label> From: &nbsp; </label>
              <input type="date" value={fromDate} onChange={(e)=>{setfromDate(e.target.value)}}></input>
            </div>
            <div style={{ marginLeft: "10px" }}>
              <label>To: &nbsp;</label>
              <input type="date" value={toDate} onChange={(e)=>{settoDate(e.target.value)}}></input>
            </div>

            <div>
              <button
                className="btn btn-primary"
                style={{ marginLeft: "10px" }}
                onClick={
                 ()=>{
                  getempDataRecord(token,id,fromDate,toDate)
                 }
                }
              >
                Get Data
              </button>
            </div>
          </div>
          <DataTable
        // title="SSL DATA"
        columns={columns}
        data={empDataRecord}
        pagination
        // paginationResetDefaultPage={resetPaginationToggle} // optionally, a hook to reset pagination to page 1
        subHeader
        // subHeaderComponent={subHeaderComponentMemo}
        // persistTableHead
        // progressPending={isloading}
        // theme= 'solarized'
        striped
      />
          </>
          
          }







          {modalType == 'addinfo' && <>
          <div className="row">
            <div className="form-group col">
              <label for="inputEmail4">Emp Name</label>
              <input type="text" className="form-control" placeholder="URL" value={empName} onChange={(e)=>setempName(e.target.value)}></input>
            </div>
           
          </div>

          <div className="row">
            <div className="form-group col">
              <label for="inputPassword4">Project</label>
              <input type="text" className="form-control" placeholder="Path" value={project} onChange={(e)=>setproject(e.target.value)}></input>
            </div>
          </div>

          <div className="row">
            <div className="form-group col">
              <label for="inputPassword4">Backup Path</label>
              <input type="text" className="form-control" placeholder="Path" value={backupPath} onChange={(e)=>setbackupPath(e.target.value)}></input>
            </div>
          </div>


          <div className="row">
            <div className="form-group col">
              <label for="inputEmail4">Date</label>
              <input type="date" className="form-control" placeholder="SSL Date" value={date} onChange={(e)=> setdate(e.target.value)} required></input>
            </div>
          </div>
          </>
          
          }

          <EmpRecordTable />
        </Modal.Body>
        <Modal.Footer>
       {modalType == 'addinfo' && <Button onClick={()=> insertempDataRecord(token,id,date,empName,project,backupPath)}>Save</Button>}
        <Button onClick={()=> setShow(false)}>Close</Button>
      </Modal.Footer>
      </Modal>
    </>
  );
}

export default EmpRecordModal;
