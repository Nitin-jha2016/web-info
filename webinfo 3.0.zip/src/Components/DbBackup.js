import React from "react";
import "../Components/Dashboard.css";
import { MyContext } from "../App";
import styled from "styled-components";
import DataTable from "react-data-table-component";
import { Modal, Button } from "react-bootstrap";
import "./Home.css";
const TextField = styled.input`
  height: 32px;
  width: 200px;
  border-radius: 3px;
  border-top-left-radius: 5px;
  border-bottom-left-radius: 5px;
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  border: 1px solid #e5e5e5;
  padding: 0 32px 0 16px;

  &:hover {
    cursor: pointer;
  }
`;

const FilterComponent = ({ filterText, onFilter, onClear }) => (
  <>
    <TextField
      id="search"
      type="text"
      placeholder="Filter By Name"
      aria-label="Search Input"
      value={filterText}
      onChange={onFilter}
    />
    <button className="clear-btn" type="button" onClick={onClear}>
      X
    </button>
  </>
);

function MyVerticallyCenteredModal(props) {
  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
      className="modal"
    >
      <Modal.Title id="contained-modal-title-vcenter">
        Modal heading
      </Modal.Title>

      <Modal.Body>
        <div className="row">
          <div className="form-group col-md-6">
            <label for="inputEmail4">dbBackupDatabase Name</label>
            <input
              type="text"
              className="form-control"
              id="inputEmail4"
              placeholder="URL"
            ></input>
          </div>
          <div className="form-group col-md-6">
            <label for="inputPassword4">IP</label>
            <input
              type="text"
              className="form-control"
              id="inputPassword4"
              placeholder="Password"
            ></input>
          </div>
        </div>

        <div className="row">
          <div className="form-group col-md-6">
            <label for="inputEmail4">Operator</label>
            <input
              type="text"
              className="form-control"
              id="inputEmail4"
              placeholder="URL"
            ></input>
          </div>
          <div className="form-group col-md-6">
            <label for="inputPassword4">Country</label>
            <input
              type="text"
              className="form-control"
              id="inputPassword4"
              placeholder="Password"
            ></input>
          </div>
        </div>

        <div className="row">
          <div className="form-group col-md-6">
            <label for="inputEmail4">Size on Source</label>
            <input
              type="text"
              className="form-control"
              id="inputEmail4"
              placeholder="URL"
            ></input>
          </div>
          <div className="form-group col-md-6">
            <label for="inputPassword4">Size on Destination</label>
            <input
              type="text"
              className="form-control"
              id="inputPassword4"
              placeholder="Password"
            ></input>
          </div>
        </div>

        <div className="row">
          <div className="form-group col-md-6">
            <label for="inputEmail4">Backup Path</label>
            <input
              type="text"
              className="form-control"
              id="inputEmail4"
              placeholder="URL"
            ></input>
          </div>
          <div className="form-group col-md-6">
            <label for="inputPassword4">Backup IP</label>
            <input
              type="text"
              className="form-control"
              id="inputPassword4"
              placeholder="Password"
            ></input>
          </div>
        </div>
      </Modal.Body>
      <Modal.Footer>
        <Button>Save</Button>
        <Button onClick={props.onHide}>Close</Button>
      </Modal.Footer>
    </Modal>
  );
}

function DbBackup() {
  const [modalShow, setModalShow] = React.useState(false);
  const { dbBackupData, isloading } = React.useContext(MyContext);

  let columns = [];

  if (dbBackupData.length > 0) {
    console.log(dbBackupData[0]);
    Object.keys(dbBackupData[0]).forEach((key) => {
      console.log(key);
      columns.push({
        name: key.toUpperCase(),
        selector: key,
        wrap: true,
      });
    });
  }

  columns.push({
    cell: (row) => (
      <button className="btn btn-dark" onClick={() => setModalShow(true)}>
        Edit
      </button>
    ),
    ignoreRowClick: true,
    allowOverflow: true,
    button: true,
  });

  columns.push({
    cell: (row) => (
      <>
        <button className="btn btn-danger">Delete</button>
      </>
    ),
    ignoreRowClick: true,
    allowOverflow: true,
    button: true,
  });

  console.log("COLUMNS: ", columns);
  console.log("dbBackupData", dbBackupData);

  const [filterText, setFilterText] = React.useState("");

  const [resetPaginationToggle, setResetPaginationToggle] = React.useState(
    false
  );

  const filteredItems = dbBackupData?.filter(
    (item) =>
      (item.path &&
        item.path.toLowerCase().includes(filterText.toLowerCase())) ||
      (item.URL && item.URL.toLowerCase().includes(filterText.toLowerCase()))
  );

  // const toggleModal = () => {
  //   setModalShow(true);
  //   console.log("modalShow", modalShow);
  // };

  const subHeaderComponentMemo = React.useMemo(() => {
    const handleClear = () => {
      if (filterText) {
        setResetPaginationToggle(!resetPaginationToggle);
        setFilterText("");
      }
    };

    console.log("modalShow", modalShow);
    return (
      <div className="d-flex justify-content-center">
        <button onClick={() => setModalShow(true)}>Add Data</button>
        <MyVerticallyCenteredModal
          show={modalShow}
          onHide={() => setModalShow(false)}
        />
        <FilterComponent
          onFilter={(e) => setFilterText(e.target.value)}
          onClear={handleClear}
          filterText={filterText}
        />
      </div>
    );
  }, [filterText, resetPaginationToggle, modalShow]);

  return (
    <>
      <DataTable
        title="Database Backup"
        columns={columns}
        data={filteredItems}
        pagination
        paginationResetDefaultPage={resetPaginationToggle} // optionally, a hook to reset pagination to page 1
        subHeader
        subHeaderComponent={subHeaderComponentMemo}
        persistTableHead
        progressPending={isloading}
      />
    </>
  );
}

export default DbBackup;
