import React,{useState} from "react";
import "../Components/Dashboard.css";
import { MyContext } from "../App";
import styled from "styled-components";
import DataTable from "react-data-table-component";
import { Modal, Button } from "react-bootstrap";
import queryString from "query-string";
import "./Home.css";

const TextField = styled.input`
  height: 32px;
  width: 200px;
  border-radius: 3px;
  border-top-left-radius: 5px;
  border-bottom-left-radius: 5px;
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  border: 1px solid #e5e5e5;
  padding: 0 32px 0 16px;

  &:hover {
    cursor: pointer;
  }
`;

const FilterComponent = ({ filterText, onFilter, onClear }) => (
  <>
    <TextField
      id="search"
      type="text"
      placeholder="Filter By Name"
      aria-label="Search Input"
      value={filterText}
      onChange={onFilter}
    />
    <button className="clear-btn" type="button" onClick={onClear}>
      X
    </button>
  </>
);

function MyVerticallyCenteredModal(props) {

  const {modalType,token,getSslData,id,sslData,sslUrl,setsslUrl,path,setpath,sslDate,setsslDate} = React.useContext(MyContext)



  React.useEffect(()=>{
    

    if(sslData.length !== 0 && id && modalType =="edit" ){
      console.log('sslData Data',sslData);
      const filteredData = sslData.filter(data => data.id == id)
      console.log('Filtered Data',filteredData);

      setsslUrl(filteredData[0].ssl_url);
      setpath(filteredData[0].path);
      setsslDate(filteredData[0].ssl_date);
           
    }else{
          setsslUrl('');
          setpath('');
          setsslDate('');
    }


  },[modalType])




const updateSslData = (token,id,sslUrl,path,sslDate)=>{
  const data = {
    id: id,
    ssl_url:sslUrl,
    path:path,
    ssl_date:sslDate
  }

  fetch("http://192.168.0.12:9633/WebInfoUpdated/Urls", {
      method: "post",
      headers: {
        "Content-Type": "application/json",
        token: token,
      },
      body: queryString.stringify({
        action: 6,
        updateRecord: JSON.stringify(data)
      }),
    })
      .then((res) => {
        if (res.status === 200) {
          return res.json();
        }
      })
      .then((data) => {
        console.log("SSLDATA", data);
        getSslData(token)
        alert('Data Updated Successfully')
        
      })
      .catch((err) => {
        console.log(err);
      });
}

const insertSslData = (token,sslUrl,path,sslDate)=>{
    const data = {
      ssl_url:sslUrl,
      path:path,
      ssl_date:sslDate
    }

    fetch("http://192.168.0.12:9633/WebInfoUpdated/Urls", {
      method: "post",
      headers: {
        "Content-Type": "application/json",
        token: token,
      },
      body: queryString.stringify({
        action: 5,
        addRecord: JSON.stringify(data)
      }),
    })
      .then((res) => {
        if (res.status === 200) {
          return res.json();
        }
      })
      .then((data) => {
        console.log("SSLDATA", data);
        getSslData(token)
        alert('Data Added Successfully')
        
      })
      .catch((err) => {
        console.log(err);
      });
}


  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
      className="modal"
    >
      <Modal.Title id="contained-modal-title-vcenter">
        Modal heading
      </Modal.Title>

      <Modal.Body>
          <div className="row">
            <div className="form-group col">
              <label for="inputEmail4">Site URL</label>
              <input type="text" className="form-control" placeholder="URL" value={sslUrl} onChange={(e)=>setsslUrl(e.target.value)}></input>
            </div>
           
          </div>

          <div className="row">
            <div className="form-group col">
              <label for="inputPassword4">Path</label>
              <input type="text" className="form-control" placeholder="Path" value={path} onChange={(e)=>setpath(e.target.value)}></input>
            </div>
          </div>

          <div className="row">
            <div className="form-group col">
              <label for="inputEmail4">SSL Date</label>
              <input type="text" className="form-control" placeholder="SSL Date" value={sslDate} onChange={(e)=> setsslDate(e.target.value)} required></input>
            </div>
          </div>

          
        
      </Modal.Body>
      <Modal.Footer>
        {modalType == 'add' && <Button onClick={()=> insertSslData(token,sslUrl,path,sslDate)}>Save</Button>}
        {modalType == 'edit'&& <Button onClick={()=> updateSslData(token,id,sslUrl,path,sslDate)}>Update</Button>}
        <Button  onClick={props.onHide}>Close</Button>
      </Modal.Footer>
    </Modal>
  );
}

function SSLData() {

  const [modalShow, setModalShow] = React.useState(false);

  const [filterText, setFilterText] = React.useState("");
  const [resetPaginationToggle, setResetPaginationToggle] = React.useState(
    false
  );
  let columns = [];

  const {isloading,token, setmodalType,sslData,getSslData,setid } = React.useContext(MyContext);

  

  React.useEffect(()=>{
    getSslData(token)
  },[])

  //DELETE SSLData
    const deleteSslData = (id)=>{

      fetch("http://192.168.0.12:9633/WebInfoUpdated/Urls", {
        method: "post",
        headers: {
          "Content-Type": "application/json",
          token: token,
        },
        body: queryString.stringify({
          action: 14,
          recordid: id
        }),
      })
        .then((res) => {
          if (res.status === 200) {
            return res.json();
          }
        })
        .then((data) => {
          console.log("DELETED", data);
          // setaddDataSuccess(true)
          getSslData(token);
          // setModalShow(false);
          alert('Data Deleted Successfully')
          
        })
        .catch((err) => {
          console.log(err);
        });
  }


  if (sslData.length > 0) {
    console.log(sslData[0]);
    Object.keys(sslData[0]).forEach((key) => {

    
      columns.push({
        name: key.toUpperCase(),
        selector: key,
        wrap: true,
      });
      
    });
  } 

  columns.push({
    cell: (row) => (
      <button className="btn btn-dark" onClick={() => {
        setModalShow(true)
        setmodalType('edit')
        setid(row.id)
        alert(row.id)
        }}>
        Edit
      </button>
    ),
    ignoreRowClick: true,
    allowOverflow: true,
    button: true,
  });

  columns.push({
    cell: (row) => (
      <>
        <button className="btn btn-danger"
         onClick={()=>{
           setid(row.id)
           deleteSslData(row.id)
         }
         }
         >Delete</button>
      </>
    ),
    ignoreRowClick: true,
    allowOverflow: true,
    button: true,
  });


  

  const filteredItems = sslData?.filter(
    (item) =>
      (item.path &&
        item.path.toLowerCase().includes(filterText.toLowerCase())) ||
      (item.URL && item.URL.toLowerCase().includes(filterText.toLowerCase()))
  );

  // const toggleModal = () => {
  //   setModalShow(true);
  //   console.log("modalShow", modalShow);
  // };

  const subHeaderComponentMemo = React.useMemo(() => {
    const handleClear = () => {
      if (filterText) {
        setResetPaginationToggle(!resetPaginationToggle);
        setFilterText("");
      }
    };




    return (
      <div className="d-flex justify-content-center">
        <button onClick={() =>{
              setModalShow(true)
              setmodalType('add')

        }         
          }
           >Add Data</button>
        <MyVerticallyCenteredModal
          show={modalShow}
          onHide={() => setModalShow(false)}
        />
        <FilterComponent
          onFilter={(e) => setFilterText(e.target.value)}
          onClear={handleClear}
          filterText={filterText}
        />
      </div>
    );
  }, [filterText, resetPaginationToggle, modalShow]);

  return (
    <>
      <DataTable
        title="Running Websites on Server"
        columns={columns}
        data={filteredItems}
        pagination
        paginationResetDefaultPage={resetPaginationToggle} // optionally, a hook to reset pagination to page 1
        subHeader
        subHeaderComponent={subHeaderComponentMemo}
        persistTableHead
        progressPending={isloading}
      />
    </>
  );
}

export default SSLData;