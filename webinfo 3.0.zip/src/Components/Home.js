import React from "react";
import "../Components/Dashboard.css";
import { MyContext } from "../App";
import styled from "styled-components";
import DataTable from "react-data-table-component";
import { Modal, Button } from "react-bootstrap";
import "./Home.css";

const TextField = styled.input`
  height: 32px;
  width: 200px;
  border-radius: 3px;
  border-top-left-radius: 5px;
  border-bottom-left-radius: 5px;
  border-top-right-radius: 0;
  border-bottom-right-radius: 0;
  border: 1px solid #e5e5e5;
  padding: 0 32px 0 16px;

  &:hover {
    cursor: pointer;
  }
`;

const FilterComponent = ({ filterText, onFilter, onClear }) => (
  <>
    <TextField
      id="search"
      type="text"
      placeholder="Filter By Name"
      aria-label="Search Input"
      value={filterText}
      onChange={onFilter}
    />
    <button className="clear-btn" type="button" onClick={onClear}>
      X
    </button>
  </>
);

function MyVerticallyCenteredModal(props) {

  const {
    siteData,
    token,
    id,
    setid,
    siteUrl,
    setsiteUrl,
    sitePath,
    setsitePath,
    ip,
    setip,
    sizeFolder,
    setsizeFolder,
    operator,
    setoperator,
    country,
    setcountry,
    backupIp,
    setbackupIp,
    backupSize,
    setbackupSize,
    backupPath,
    setbackupPath,
    insertSiteData,
    updateSiteData,
    modalType,
    clearInputs

  } = React.useContext(MyContext);

  React.useEffect(()=>{
    // alert(2)

    // setbackupSize('')
    // setcountry('')
    // setip('')
    // setoperator('')
    // setbackupPath('')
    // setsitePath('')
    // setsiteUrl('')
    // setsizeFolder('')
    // setbackupIp('')
},[])

  React.useEffect(()=>{
    // alert(1)
    if(siteData.length !== 0 && id && modalType ==='update'){
      console.log('site Data',siteData);
      const filteredData = siteData.filter(data => data.id == id)
      console.log('Filtered Data',filteredData);

      setbackupSize(filteredData[0].backup_size)
      setcountry(filteredData[0].country)
      setip(filteredData[0].ip)
      setoperator(filteredData[0].operator)
      setbackupPath(filteredData[0].backup_path)
      setsitePath(filteredData[0].site_path)
      setsiteUrl(filteredData[0].site_url)
      setsizeFolder(filteredData[0].size_folder)
      setbackupIp(filteredData[0].backup_ip)
    }else{
      clearInputs()
      alert('inputs cleared')
    }
  },[modalType])

  
console.log('Modal Type',modalType);
  return (
    <Modal
      {...props}
      size="lg"
      aria-labelledby="contained-modal-title-vcenter"
      centered
      className="modal"
    >
      <Modal.Title id="contained-modal-title-vcenter">
        Modal heading
      </Modal.Title>

      <Modal.Body>
        <div className="row">
          <div className="form-group col-md-6">
            <label for="inputEmail4">Site URL</label>
            <input
              type="text"
              className="form-control"
              id="inputEmail4"
              placeholder="URL"
              value={siteUrl}
              onChange={(e) => setsiteUrl(e.target.value)}
            ></input>
          </div>
          <div className="form-group col-md-6">
            <label for="inputPassword4">Path</label>
            <input
              type="text"
              className="form-control"
              placeholder="path"
              value={sitePath}
              onChange={(e) => setsitePath(e.target.value)}
            ></input>
          </div>
        </div>

        <div className="row">
          <div className="form-group col-md-6">
            <label for="inputEmail4">Size of folder</label>
            <input
              type="text"
              className="form-control"
              id="inputEmail4"
              placeholder="Size of folder"
              value={sizeFolder}
              onChange={(e) => setsizeFolder(e.target.value)}
            ></input>
          </div>
          <div className="form-group col-md-6">
            <label for="inputPassword4">Operator</label>
            <input
              type="text"
              className="form-control"
              placeholder="Operator"
              value={operator}
              onChange={(e) => setoperator(e.target.value)}
            ></input>
          </div>
        </div>

        <div className="row">
          <div className="form-group col-md-6">
            <label for="inputEmail4">Country</label>
            <input
              type="text"
              className="form-control"
              placeholder="Country"
              value={country}
              onChange={(e) => setcountry(e.target.value)}
            ></input>
          </div>
          <div className="form-group col-md-6">
            <label for="inputPassword4">Backup IP</label>
            <input
              type="text"
              className="form-control"
              placeholder="Backup IP"
              value={backupIp}
              onChange={(e) => setbackupIp(e.target.value)}
            ></input>
          </div>
        </div>

        <div className="row">
          <div className="form-group col-md-6">
            <label for="inputEmail4">Backup Size</label>
            <input
              type="text"
              className="form-control"
              placeholder="Backup Size"
              value={backupSize}
              onChange={(e) => setbackupSize(e.target.value)}
            ></input>
          </div>
          <div className="form-group col-md-6">
            <label for="inputPassword4">Backup Path</label>
            <input
              type="text"
              className="form-control"
              id="inputPassword4"
              placeholder="Backup Path"
              value={backupPath}
              onChange={(e) => setbackupPath(e.target.value)}
            ></input>
          </div>
        </div>

        <div className="row">
          <div className="form-group col">
            <label for="inputPassword4">IP</label>
            <input
              type="text"
              className="form-control"
              placeholder="IP"
              value={ip}
              onChange={(e) => setip(e.target.value)}
            ></input>
          </div>
        </div>
      </Modal.Body>
      <Modal.Footer>
    {modalType == "add" &&  <Button
          onClick={() => {
            insertSiteData(
              token,
              siteUrl,
              sitePath,
              ip,
              sizeFolder,
              operator,
              country,
              backupIp,
              backupSize,
              backupPath);
          }}
        >
          Save
        </Button>}
       {modalType === 'update' && <Button
          onClick={() => {
          updateSiteData(
              token,
              id,
              siteUrl,
              sitePath,
              ip,
              sizeFolder,
              operator,
              country,
              backupIp,
              backupSize,
              backupPath);
          }}
        >
          Update
        </Button>}
        <Button onClick={props.onHide}>Close</Button>
      </Modal.Footer>
    </Modal>
  );
}

function Home() {
 
  const { siteData, isloading,modalShow,setModalShow,setid,setmodalType,clearInputs,deleteSiteUrl,setsslUrl,setpath,setsslDate} = React.useContext(MyContext);

  let columns = [];

  if (siteData.length > 0) {
    console.log(siteData[0]);
    Object.keys(siteData[0]).forEach((key) => {
      if (key === "status") {
        columns.push({
          name: key.toUpperCase(),
          cell: (row) => (
            <input type="checkbox" checked={Boolean(row.status)}></input>
            // <p>{console.log('row',row)}</p>
          ),
        });
      } else {
        columns.push({
          name: key.toUpperCase(),
          selector: key,
          wrap: true,
        });
      }
    });
  }

  // columns.push({
  //   name: 'STATUS',
  //   cell: (row) => (
  //     <>
  //       <input type="checkbox"></input>
  //     </>
  //   ),
  //   ignoreRowClick: true,
  //   allowOverflow: true,

  // });

  const editHandler=(id)=>{
    // console.log('ROW',id);
    // alert(id)
    setid(id)
    setModalShow(true)
    setmodalType('update')
  }

  columns.push({
    cell: (row) => (
      <button className="btn btn-dark" onClick={() => editHandler(row.id)}>
        Edit
      </button>
    ),
    ignoreRowClick: true,
    allowOverflow: true,
    button: true,
  });

  columns.push({
    cell: (row) => (
      <>
        <button className="btn btn-danger" onClick={()=>{
          setid(row.id)
          alert(row.id)
          deleteSiteUrl(row.id)
        }}>Delete</button>
      </>
    ),
    ignoreRowClick: true,
    allowOverflow: true,
    button: true,
  });

  // console.log("COLUMNS: ", columns);
  // console.log("DATA", siteData);

  const [filterText, setFilterText] = React.useState("");

  const [resetPaginationToggle, setResetPaginationToggle] = React.useState(
    false
  );
  console.log('SIte Daata',siteData);
  const filteredItems = siteData?.filter(
    (item) =>
      (item.site_path &&
        item.site_path.toLowerCase().includes(filterText.toLowerCase())) ||
      (item.URL && item.URL.toLowerCase().includes(filterText.toLowerCase()))
  );

  // const toggleModal = () => {
  //   setModalShow(true);
  //   console.log("modalShow", modalShow);
  // };

  const subHeaderComponentMemo = React.useMemo(() => {
    const handleClear = () => {
      if (filterText) {
        setResetPaginationToggle(!resetPaginationToggle);
        setFilterText("");
      }
    };

    console.log("modalShow", modalShow);
    return (
      <div className="d-flex justify-content-center">
        <button onClick={() => {
          
          
          setmodalType('add')
          setModalShow(true)
          // clearInputs()
    
          }}>Add Data</button>
        <MyVerticallyCenteredModal
          show={modalShow}
          onHide={() => setModalShow(false)}
        />
        <FilterComponent
          onFilter={(e) => setFilterText(e.target.value)}
          onClear={handleClear}
          filterText={filterText}
        />
      </div>
    );
  }, [filterText, resetPaginationToggle, modalShow]);

  return (
    <>
      <DataTable
        title="Running Websites on Server"
        columns={columns}
        data={filteredItems}
        pagination
        paginationResetDefaultPage={resetPaginationToggle} // optionally, a hook to reset pagination to page 1
        subHeader
        subHeaderComponent={subHeaderComponentMemo}
        persistTableHead
        progressPending={isloading}
      />
    </>
  );
}

export default Home;
