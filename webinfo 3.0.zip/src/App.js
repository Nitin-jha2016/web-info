import React from "react";
import "./App.css";
import Dashboard from "./Components/Dashboard";
import Login from "./Components/Login";
import queryString from "query-string";
import { createContext, useState } from "react";

export const MyContext = createContext();

function App() {
  const [token, settoken] = useState(null);
  const [tokenExpiaryDate, settokenExpiaryDate] = useState(null);
  const [isTokenExpied, setisTokenExpied] = useState(false);
  const [user, setuser] = useState(null);
  const [isAdmin, setisAdmin] = useState(false);

  const [username, setusername] = useState("");
  const [password, setpassword] = useState("");
  const [isloading, setisloading] = useState(false);
  const [isalertOpen, setisalertOpen] = useState(false);

  const [search, setsearch] = useState("");
  const [ssl, setssl] = useState([]);
  const [expiredSSL, setexpiredSSL] = useState([]);

  //DATA
  const [siteData, setSiteData] = useState([]); 
  const [dbBackupData, setdbBackupData] = useState([]);
  const [empData, setempData] = useState([]);

  //SITE DATA
  const [id, setid] = useState("")
  const [siteUrl, setsiteUrl] = useState("");
  const [sitePath, setsitePath] = useState("");
  const [ip, setip] = useState("");
  const [sizeFolder, setsizeFolder] = useState("");
  const [operator, setoperator] = useState("");
  const [country, setcountry] = useState("");
  const [backupIp, setbackupIp] = useState("");
  const [backupSize, setbackupSize] = useState("");
  const [backupPath, setbackupPath] = useState("");
  
  //SSL Data
  const [sslData, setsslData] = React.useState([]);
  const [sslUrl, setsslUrl] = useState('')
  const [path, setpath] = useState('')
  const [sslDate, setsslDate] = useState('')

  const [addDataSuccess, setaddDataSuccess] = useState(false)

  const [modalShow, setModalShow] = React.useState(false);
  const [modalType, setmodalType] = useState('')

  //CHECK IF THE USER EXISTS OR NOT
  React.useEffect(() => {
    const tk = localStorage.getItem("token");
    // console.log("FOunded token", tk);

    const tokenExDate = localStorage.getItem("tokenExpiaryDate");
    // console.log("Token Exp Date", tokenExDate);

    const currentDateObj = new Date();
    // console.log("currentDate", currentDateObj);

    if (tk && tokenExDate) {
      let edatetrimmed = tokenExDate.substr(0, 19);
      console.log("Expiarydate trimmed", edatetrimmed);
      let expDateObj = new Date(edatetrimmed);
      // console.log("exp date obj", expDateObj);

      if (currentDateObj < expDateObj) {
        settoken(tk);
        getSiteData(tk);
      } else {
        alert("Token Expired");
        setisTokenExpied(true);
        logOut();
      }
    }
    // console.log('SIte Daata',siteData);
  }, [token]);

  // React.useEffect(() => {
  //     //  getSiteData(token)
  // }, [addDataSuccess])

  //LOGIN
  const handleLogIn = () => {
    // console.log("Usernme", username);

    const requestOption = {
      method: "POST",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
      },
      body: queryString.stringify({
        username: username,
        password: password,
      }),
    };

    fetch("http://192.168.0.12:9633/WebInfoUpdated/validate", requestOption)
      .then((res) => {
        return res.json();
      })
      .then((res) => {
        console.log("RES", res.data);
        settoken(res.data.token);
        settokenExpiaryDate(res.data.expiration_time);
        localStorage.setItem("tokenExpiaryDate", res.data.expiration_time);
        localStorage.setItem("token", res.data.token);
        getSiteData(res.data.token);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  //LOG OUT
  const logOut = () => {
    settoken(null);
    settokenExpiaryDate(null);
    setssl([]);
    setexpiredSSL([]);
    localStorage.clear();
  };

  //GET DATA
  const getSiteData = (token) => {
    var requestOptions = {
      method: "post",
      headers: {
        "Content-Type": "application/x-www-form-urlencoded",
        token: token,
      },
      body: queryString.stringify({ action: 1 }),
    };

    setisloading(true);
    fetch("http://192.168.0.12:9633/WebInfoUpdated/Urls", requestOptions)
      .then((res) => {
        if (res.status === 200) {
          return res.json();
        }
      })
      .then((data) => {
        // console.log('DATA',data.data.ssllist);
        // data.data.forEach((item) => {
        //   if (!item.hasOwnProperty("SSL_Date")) {

        //     item.SSL_Date = "No SSL DATE";
        //   }
        // });
        if (data) {
          setSiteData(data.data.ssllist);
          {console.log('Data',data.data.ssllist);}
          setisloading(false);
        }

        // let mydate = new Date();
        // let currentDateString = mydate.toISOString().slice(0, 10);
        // let currentDateTime = new Date(currentDateString).getTime();

        // data.data.forEach((item) => {
        //   if (item.SSL_Date) {
        //     let sslDateTime = new Date(item.SSL_Date).getTime();
        //     let difference = sslDateTime - currentDateTime;
        //     if (difference <= 172800000 && difference >= 0) {
        //       // console.log("Hi");
        //       setssl((prev) => {
        //         let newValue = [...prev, item];
        //         return newValue;
        //       });
        //     }
        //     if (difference < 0) {
        //       // console.log("hii");
        //       setexpiredSSL((prev) => {
        //         let Value = [...prev, item];
        //         return Value;
        //       });
        //     }
        //   }
        // });
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const getSslData = (token)=>{
    fetch("http://192.168.0.12:9633/WebInfoUpdated/Urls", {
    method: "post",
    headers: {
      "Content-Type": "application/json",
      token: token,
    },
    body: queryString.stringify({
      action: 4
    }),
  })
    .then((res) => {
      if (res.status === 200) {
        return res.json();
      }
    })
    .then((data) => {
      // console.log('SSLData',sslData);
      console.log("SSL DATA", data.data.ssllist);
      setsslData(data.data.ssllist)
      // setaddDataSuccess(true)
      // setModalShow(false);
      
    })
    .catch((err) => {
      console.log(err);
    });
  }


  //INSERT SITE DATA
  const insertSiteData = (
    token,
    siteUrl,
    sitePath,
    ip,
    sizeFolder,
    operator,
    country,
    backupIp,
    backupSize,
    backupPath
  ) => {
    const data = {
      site_url: siteUrl,
      site_path: sitePath,
      ip: ip,
      size_folder: sizeFolder,
      operator: operator,
      country: country,
      backup_ip: backupIp,
      backup_size: backupSize,
      backup_path: backupPath,
      status: 0
    };

    console.log("Data", data);

    clearInputs()


    fetch("http://192.168.0.12:9633/WebInfoUpdated/Urls", {
      method: "post",
      headers: {
        "Content-Type": "application/json",
        token: token,
      },
      body: queryString.stringify({
        action: 2,
        addRecord: JSON.stringify(data)
      }),
    })
      .then((res) => {
        if (res.status === 200) {
          return res.json();
        }
      })
      .then((data) => {
        console.log("DATA", data);
        // setaddDataSuccess(true)
        getSiteData(token);
        // setModalShow(false);
        alert('Data Added Successfully')
        
      })
      .catch((err) => {
        console.log(err);
      });
  };


  const updateSiteData = (

    token,
    id,
    siteUrl,
    sitePath,
    ip,
    sizeFolder,
    operator,
    country,
    backupIp,
    backupSize,
    backupPath
  ) => {
    const data = {
      id: id,
      site_url: siteUrl,
      site_path: sitePath,
      ip: ip,
      size_folder: sizeFolder,
      operator: operator,
      country: country,
      backup_ip: backupIp,
      backup_size: backupSize,
      backup_path: backupPath,
      status: 0
    };

    // console.log("Data", data);


    fetch("http://192.168.0.12:9633/WebInfoUpdated/Urls", {
      method: "post",
      headers: {
        "Content-Type": "application/json",
        token: token,
      },
      body: queryString.stringify({
        action: 3,
        updateRecord: JSON.stringify(data)
      }),
    })
      .then((res) => {
        if (res.status === 200) {
          return res.json();
        }
      })
      .then((data) => {
        console.log("DATA", data);
        // setaddDataSuccess(true)
        getSiteData(token);
        // setModalShow(false);
        alert('Data Updated Successfully')
        
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const clearInputs = ()=>{
    setbackupSize('')
    setcountry('')
    setip('')
    setoperator('')
    setbackupPath('')
    setsitePath('')
    setsiteUrl('')
    setsizeFolder('')
    setbackupIp('')
  }

  const deleteSiteUrl = (id) => {    
    
    fetch("http://192.168.0.12:9633/WebInfoUpdated/Urls", {
      method: "post",
      headers: {
        "Content-Type": "application/json",
        token: token,
      },
      body: queryString.stringify({
        action: 13,
        recordid: id
      }),
    })
      .then((res) => {
        if (res.status === 200) {
          return res.json();
        }
      })
      .then((data) => {
        console.log("DELETED", data);
        // setaddDataSuccess(true)
        getSiteData(token);
        // setModalShow(false);
        alert('Data Deleted Successfully')
        
      })
      .catch((err) => {
        console.log(err);
      });
  };



  const filterRecords = () => {};

  // const addSslData = ()=>{
  //   fetch("http://192.168.0.12:9633/WebInfoUpdated/",requestOptions)
  // }

  // console.log("Expired SSl", expiredSSL);
  return (
    <MyContext.Provider
      value={{
        sslData,
        getSslData,
        user,
        setuser,
        token,
        settoken,
        username,
        setusername,
        password,
        setpassword,
        isloading,
        setisloading,
        siteData,
        setSiteData,
        search,
        setsearch,
        ssl,
        setssl,
        isalertOpen,
        setisalertOpen,
        handleLogIn,
        logOut,
        expiredSSL,
        dbBackupData,
        setdbBackupData,
        empData,
        setempData,

        insertSiteData,
        updateSiteData,

        id,
        setid,

        siteUrl,
        setsiteUrl,

        sitePath,
        setsitePath,

        ip,
        setip,

        sizeFolder,
        setsizeFolder,

        operator,
        setoperator,

        country,
        setcountry,

        backupIp,
        setbackupIp,

        backupSize,
        setbackupSize,

        backupPath,
        setbackupPath,

        setaddDataSuccess,

        sslUrl,setsslUrl,path,setpath,sslDate,setsslDate, //SSLDATA

        modalShow,
         setModalShow,

         modalType,
         setmodalType,

         clearInputs,

         deleteSiteUrl
      }}
    >
      <div className="App">{token ? <Dashboard /> : <Login />}</div>
    </MyContext.Provider>
  );
}

export default App;
